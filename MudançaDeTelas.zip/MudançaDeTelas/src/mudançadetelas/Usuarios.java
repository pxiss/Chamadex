/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mudançadetelas;

/**
 *
 * @author guilherme.vschutz
 */
public class Usuarios {
    
    private String nomeusuario;
    private String senhausuario;

    public Usuarios(String nomeuser, String senhauser) {
        this.nomeusuario = nomeuser;
        this.senhausuario = senhauser;
    }

    public String getName() {
        return nomeusuario;
    }

    public String getPassword() {
        return senhausuario;
    }

    
}
